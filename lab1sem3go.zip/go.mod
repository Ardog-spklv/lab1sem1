module lab1_avl

go 1.22.2
